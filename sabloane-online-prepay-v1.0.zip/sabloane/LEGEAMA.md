# Sabloane Online Prepay (versiune 1.0, 27 nov 2026)

Mod de lucru: copiaza folderul `clipuri` si `audio_logo` in /tmp/v2 (scripturile folosesc aceasta cale), ruleaza cu Python + Playwright (Chromium) si ffmpeg.

- statice/: postare 1080x1350 (template.html + render.py, logo si captura site).
- clipuri/gen2.py: clip FAQ 6 scene (1080x1920); build_faq.sh il asambleaza cu muzica.
- clipuri/gen4.py: clip "Reincarca online", design original (intunecat/deschis).
- clipuri/gen5.py: Povesti "Cum reincarci" si coperti Repere.
- clipuri/gen3.py, gen.py: variante vechi (de pastrat ca alternativa).
- audio_logo/: logo.png (nu se redeseneaza), beat.wav (ritm original 120 bpm, kick + hi-hat).

Font actual: DejaVu Sans. Planificat: Montserrat (titluri) + Inter (text), vezi documentul Design.
Reguli: primul cadru nu negru; text in jumatatea de sus; fapte doar din INDEX; fara date personale in capturi.

## Istoric versiuni
- v1.0 (27 nov 2026): primul pachet.
