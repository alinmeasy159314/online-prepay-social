#!/bin/bash
# Construieste un clip FAQ din 6 cadre: ./build_faq.sh prefix iesire.mp4
# Cadrele: prefix-s1.png ... prefix-s6.png (1080x1920), generate de gen2.py
P=$1; OUT=$2
ffmpeg -y -loop 1 -t 2.5 -i $P-s1.png -loop 1 -t 2.5 -i $P-s2.png -loop 1 -t 2.5 -i $P-s3.png \
 -loop 1 -t 2.5 -i $P-s4.png -loop 1 -t 2.5 -i $P-s5.png -loop 1 -t 2.5 -i $P-s6.png \
 -stream_loop -1 -i /tmp/v2/beat.wav \
 -filter_complex "[0][1]xfade=transition=slideleft:duration=0.25:offset=2.25[a];[a][2]xfade=transition=slideleft:duration=0.25:offset=4.5[b];[b][3]xfade=transition=slideleft:duration=0.25:offset=6.75[c];[c][4]xfade=transition=slideleft:duration=0.25:offset=9[d];[d][5]xfade=transition=slideleft:duration=0.25:offset=11.25,format=yuv420p[v];[6:a]volume=0.8,afade=t=in:st=0:d=0.5,afade=t=out:st=13:d=0.8[a]" \
 -map "[v]" -map "[a]" -t 13.76 -c:v libx264 -crf 20 -c:a aac $OUT
