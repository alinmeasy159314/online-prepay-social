import os
from playwright.sync_api import sync_playwright

CLIPS = {
 "clip0-reincarca-online":[("Reîncarcă cartela","PrePay online","hook"),("Alege","operatorul","ops"),("Reîncarci și","TV Focus Sat","none"),("Fără cont","obligatoriu","none"),("Rapid, simplu","și sigur","cta")],
}
CSS = """*{box-sizing:border-box;margin:0}body{width:1080px;height:1920px;font-family:'DejaVu Sans',Arial,sans-serif}
#s{width:1080px;height:1920px;position:relative;overflow:hidden;background:linear-gradient(160deg,#fff 0%,#d9f1fb 60%,#b9e6f8 100%);color:#0d1b2a}
#s:before{content:"";position:absolute;right:-260px;top:-200px;width:900px;height:900px;border-radius:50%;background:radial-gradient(circle,#37C0ED 0%,transparent 66%);opacity:.35}
.logo{position:absolute;left:50%;transform:translateX(-50%);top:110px;height:110px}
.t{position:absolute;left:50px;right:50px;text-align:center;top:250px;font-size:120px;font-weight:800;line-height:1.1;letter-spacing:-3px}.t span{display:block;color:#1aa6dc}
.dots{position:absolute;right:70px;top:140px;display:flex;gap:16px}.dots i{width:70px;height:12px;border-radius:6px;background:#bcd9e6}.dots i.on{background:#37C0ED}
.box{position:absolute;left:0;right:0;top:640px;display:flex;gap:22px;flex-wrap:wrap;justify-content:center;padding:0 60px}
.box span{background:#fff;border-radius:40px;padding:24px 44px;font-size:58px;font-weight:800;box-shadow:0 10px 24px rgba(0,0,0,.08)}
.num{background:#fff;border-radius:28px;padding:34px 54px;font-size:74px;font-weight:700;letter-spacing:4px;box-shadow:0 10px 24px rgba(0,0,0,.08)}
.btn{background:#37C0ED;color:#06323a;border-radius:70px;padding:34px 80px;font-size:68px;font-weight:800;box-shadow:0 14px 30px rgba(0,0,0,.14)}
.url{position:absolute;left:0;right:0;text-align:center;top:900px;font-size:62px;font-weight:800;color:#06323a}.url small{display:block;font-size:38px;font-weight:600;color:#33475b;margin-top:12px}
"""+open("/tmp/v2/phone_css.txt",encoding="utf-8").read()+"""
.mfoot{margin:22px 26px 0;background:#e6f6fd;border-radius:16px;padding:16px 10px;text-align:center;font-size:22px;font-weight:800;color:#1aa6dc}.mst{padding:14px 26px!important;font-size:25px!important}.pw{position:absolute;left:0;right:0;top:920px;height:1000px;overflow:hidden}.pw .ph{position:absolute;left:281px;top:0;right:auto;transform:rotate(0deg) scale(1.1);transform-origin:top left;width:470px;height:800px}
"""

BTN={'clip0-reincarca-online':'Reîncarcă acum','faq1-plata': 'Vezi răspunsul', 'faq2-cod-spam': 'Vezi cum', 'faq3-credit-optiune': 'Alege tipul', 'faq4-mai-multe': 'Reîncarcă acum'}
def extra(kind, name, a="", b=""):
    if kind == "ops":
        return '<div class=box><span style="color:#FF7900">Orange</span><span style="color:#E60000">Vodafone</span><span style="color:#0B5FFF">DIGI</span><span style="color:#33475b">Focus Sat</span></div>'
    if kind == "num":
        return '<div class=box><div class=num>07XX XXX XXX</div></div>'
    if kind == "pay":
        return '<div class=box><span>Plată prin <b style="color:#1aa6dc">PayU</b></span></div>'
    if kind == "tick":
        return '<div class=box style="top:620px"><div style="width:150px;height:150px;border-radius:50%;background:#37C0ED;color:#06323a;font-size:100px;font-weight:800;display:flex;align-items:center;justify-content:center;box-shadow:0 14px 30px rgba(0,0,0,.14)">✓</div></div>'
    if kind == "cta":
        return f'<div class=box style="top:600px"><div class=btn>{BTN[name]}</div></div><div class=url style="top:770px">online-prepay.ro<small>Linkul e în bio · 24/7</small></div>'
    return ''

PH=open('/tmp/v2/phone_html2.txt',encoding='utf-8').read()

def html(a, b, kind, i, name):
    if kind in ('hook','none','tick'): PT,SC,LF=830,1.3,234
    elif kind=='cta': PT,SC,LF=960,1.15,270
    else: PT,SC,LF=940,1.2,258
    PHX=PH.replace('<div class=ph>','<div class=ph style="left:%dpx;transform:scale(%s)">'%(LF,SC),1)
    dots = "".join('<i class="on"></i>' if j == i else '<i></i>' for j in range(5))
    return f'<style>{CSS}</style><div id=s><img class=logo src=logo.png><div class=t >{a}<span>{b}</span></div>{extra(kind,name,a,b)}<div class=pw style="top:{PT}px;height:{1920-PT}px">{PHX}</div></div>'

os.chdir("/tmp/v2")
with sync_playwright() as p:
    br = p.chromium.launch()
    pg = br.new_page(viewport={"width": 1080, "height": 1920})
    for name, scenes in CLIPS.items():
        for i, (a, b, kind) in enumerate(scenes):
            open("tmp.html", "w", encoding="utf-8").write(html(a, b, kind, i, name))
            pg.goto("file:///tmp/v2/tmp.html")
            pg.wait_for_timeout(250)
            pg.locator("#s").screenshot(path=f"{name}-s{i+1}.png")
    br.close()
print("done")
