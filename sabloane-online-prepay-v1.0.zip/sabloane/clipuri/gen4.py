
import os
from playwright.sync_api import sync_playwright
PH=open('/tmp/v2/phone_html2.txt',encoding='utf-8').read()
PCSS=open('/tmp/v2/phone_css.txt',encoding='utf-8').read()
CSS="""*{box-sizing:border-box;margin:0}body{width:1080px;height:1920px;font-family:'DejaVu Sans',Arial,sans-serif}
#s{width:1080px;height:1920px;position:relative;overflow:hidden}
.dark{background:linear-gradient(170deg,#0b4a96 0%,#0a3270 45%,#082355 100%);color:#fff}
.light{background:linear-gradient(170deg,#fff 0%,#e3f4fc 55%,#c6ebf9 100%);color:#0d1b2a}
.card{position:absolute;left:70px;top:110px;background:#fff;border-radius:34px;padding:22px 34px;box-shadow:0 10px 30px rgba(0,0,0,.18)}.card img{height:100px;display:block}
.t{position:absolute;left:70px;right:70px;top:300px;font-size:104px;font-weight:800;line-height:1.12;letter-spacing:-2px}.t b{display:block;color:#37C0ED}.light .t b{color:#1aa6dc}
.sub{position:absolute;left:70px;right:70px;font-size:52px;font-weight:600;opacity:.9}
.panel{position:absolute;left:70px;right:70px;top:760px;background:rgba(255,255,255,.12);border-radius:40px;padding:50px;font-size:64px;font-weight:800;text-align:center;line-height:1.25}
.chips{position:absolute;left:70px;right:70px;top:1090px;display:flex;gap:18px;justify-content:center;flex-wrap:wrap;font-size:52px;font-weight:800}.chips span{background:#fff;border-radius:40px;padding:22px 40px}
.op{position:absolute;left:70px;right:70px;background:#fff;border-radius:36px;padding:38px 44px;font-size:64px;font-weight:800;display:flex;align-items:center;gap:36px;box-shadow:0 12px 28px rgba(0,0,0,.1);color:#0d1b2a}.op i{width:72px;height:72px;border-radius:18px;display:block}
.tv{position:absolute;left:120px;right:120px;top:800px;height:560px;background:#fff;border-radius:60px;box-shadow:0 20px 40px rgba(0,0,0,.25)}.tv:before{content:"";position:absolute;left:60px;right:60px;top:60px;bottom:90px;background:#1479c5;border-radius:30px}.tv:after{content:"";position:absolute;left:50%;top:48%;margin-left:-60px;border-left:130px solid #fff;border-top:80px solid transparent;border-bottom:80px solid transparent;transform:translate(-30px,-80px)}
.url{position:absolute;left:70px;right:70px;top:780px;background:#fff;border-radius:44px;padding:60px 30px;text-align:center;font-size:78px;font-weight:800;color:#0b3a7a;white-space:nowrap;box-shadow:0 16px 36px rgba(0,0,0,.25)}
.btn{position:absolute;left:150px;right:150px;top:1060px;background:#37C0ED;color:#06323a;border-radius:80px;padding:44px 0;text-align:center;font-size:74px;font-weight:800;box-shadow:0 14px 30px rgba(0,0,0,.25)}
.foot{position:absolute;left:70px;right:70px;top:1260px;text-align:center;font-size:44px;font-weight:700;opacity:.9;line-height:1.4}
.pw{position:absolute;left:0;right:0;top:830px;height:1090px;overflow:hidden}.pw .ph{position:absolute;left:258px;top:0;transform:scale(1.2);transform-origin:top left;width:470px;height:800px}
"""+PCSS+"""
.mfoot{margin:22px 26px 0;background:#e6f6fd;border-radius:16px;padding:16px 10px;text-align:center;font-size:22px;font-weight:800;color:#1aa6dc}.mst{padding:14px 26px!important;font-size:25px!important}
"""
LOGO='<div class=card><img src=logo.png></div>'
def S1(): return 'dark',LOGO+'<div class=t>Reîncărcare cartele PrePay<b>online</b></div><div class=panel>DIN ORICE<br>COLȚ AL LUMII</div><div class=chips><span style="color:#FF7900">Orange</span><span style="color:#E60000">Vodafone</span><span style="color:#0B5FFF">DIGI</span></div>'
def S2(): return 'light',LOGO+'<div class=t>Reîncărcare<b>PrePay online</b></div><div class=sub style="top:640px">Alege operatorul</div><div class=op style="top:750px"><i style="background:#FF7900"></i>Orange PrePay</div><div class=op style="top:960px"><i style="background:#E60000"></i>Vodafone PrePay</div><div class=op style="top:1170px"><i style="background:#0B5FFF"></i>DIGI PrePay</div>'
def S3(): return 'dark',LOGO+'<div class=t>Și reîncărcare<b>TV Focus Sat</b></div><div class=tv></div><div class=foot style="top:1440px">Servicii de reîncărcare<br>pentru televiziune</div>'
def S4(): 
    PHX=PH.replace('<div class=ph>','<div class=ph>',1)
    return 'light',LOGO+'<div class=t>Fără cont<b>obligatoriu</b></div><div class=sub style="top:640px;color:#33475b">Comanzi online, simplu.</div><div class=pw>'+PHX+'</div>'
def S5(): return 'dark',LOGO+'<div class=t>Rapid, simplu<b>și sigur</b></div><div class=url>online-prepay.ro</div><div class=btn>Reîncarcă acum</div><div class=foot>Linkul e în bio · 24/7</div>'
os.chdir('/tmp/v2')
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1080,'height':1920})
    for i,f in enumerate([S1,S2,S3,S4,S5]):
        cls,body=f()
        open('tmp4.html','w',encoding='utf-8').write('<style>'+CSS+'</style><div id=s class="'+cls+'">'+body+'</div>')
        pg.goto('file:///tmp/v2/tmp4.html'); pg.wait_for_timeout(250)
        pg.locator('#s').screenshot(path='old-s%d.png'%(i+1))
    br.close()
