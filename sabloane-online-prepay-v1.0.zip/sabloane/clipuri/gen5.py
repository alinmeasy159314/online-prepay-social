
import os
from playwright.sync_api import sync_playwright
CSS="""*{box-sizing:border-box;margin:0}body{width:1080px;height:1920px;font-family:'DejaVu Sans',Arial,sans-serif}
#s{width:1080px;height:1920px;position:relative;overflow:hidden}
.dark{background:linear-gradient(170deg,#0b4a96 0%,#0a3270 45%,#082355 100%);color:#fff}
.light{background:linear-gradient(170deg,#fff 0%,#e3f4fc 55%,#c6ebf9 100%);color:#0d1b2a}
.card{position:absolute;left:50%;transform:translateX(-50%);top:270px;background:#fff;border-radius:34px;padding:20px 34px;box-shadow:0 10px 30px rgba(0,0,0,.18)}.card img{height:96px;display:block}
.badge{position:absolute;left:0;right:0;top:470px;text-align:center}.badge span{display:inline-block;background:#37C0ED;color:#06323a;border-radius:50px;padding:16px 44px;font-size:44px;font-weight:800;letter-spacing:2px}
.t{position:absolute;left:70px;right:70px;top:580px;text-align:center;font-size:104px;font-weight:800;line-height:1.1;letter-spacing:-2px}.t b{display:block;color:#37C0ED}.light .t b{color:#1aa6dc}
.sub{position:absolute;left:70px;right:70px;text-align:center;font-size:54px;font-weight:600;opacity:.9}
.op{position:absolute;left:110px;right:110px;background:#fff;border-radius:36px;padding:34px 44px;font-size:62px;font-weight:800;display:flex;align-items:center;gap:36px;box-shadow:0 12px 28px rgba(0,0,0,.12);color:#0d1b2a}.op i{width:68px;height:68px;border-radius:18px;display:block}
.field{position:absolute;left:110px;right:110px;background:#fff;border-radius:30px;padding:30px 44px;color:#0d1b2a;box-shadow:0 12px 28px rgba(0,0,0,.2)}.field small{display:block;font-size:34px;font-weight:600;color:#5b6b7b;margin-bottom:10px}.field b{font-size:60px;letter-spacing:3px}
.btn{position:absolute;left:150px;right:150px;background:#37C0ED;color:#06323a;border-radius:80px;padding:40px 0;text-align:center;font-size:66px;font-weight:800;box-shadow:0 14px 30px rgba(0,0,0,.25)}
.chips{position:absolute;left:70px;right:70px;display:flex;gap:18px;justify-content:center;flex-wrap:wrap;font-size:50px;font-weight:800}.chips span{background:#fff;border-radius:40px;padding:20px 38px}
.pill{position:absolute;left:150px;right:150px;background:#fff;border-radius:60px;padding:50px;text-align:center;font-size:110px;font-weight:800;color:#0b3a7a;box-shadow:0 16px 36px rgba(0,0,0,.15)}
.foot{position:absolute;left:70px;right:70px;text-align:center;font-size:46px;font-weight:700;opacity:.92;line-height:1.4}
.check{position:absolute;left:50%;margin-left:-110px;width:220px;height:220px;border-radius:50%;background:#37C0ED;color:#06323a;font-size:150px;font-weight:800;display:flex;align-items:center;justify-content:center;box-shadow:0 18px 40px rgba(0,0,0,.3)}
.cov{position:absolute;left:50%;top:50%;margin:-330px 0 0 -330px;width:660px;height:660px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;font-weight:800;text-align:center}
"""
LOGO='<div class=card><img src=logo.png></div>'
def S1(): return 'dark',LOGO+'<div class=t style="top:470px">Cum reîncarci<b>cartela PrePay</b><span style="display:block;font-size:104px">online?</span></div><div class=sub style="top:1060px">4 pași simpli</div><div class=chips style="top:1180px"><span style="color:#FF7900">Orange</span><span style="color:#E60000">Vodafone</span><span style="color:#0B5FFF">DIGI</span><span style="color:#33475b">Focus Sat</span></div>'
def S2(): return 'light',LOGO+'<div class=badge><span>PASUL 1</span></div><div class=t>Alegi<b>operatorul</b></div><div class=op style="top:940px"><i style="background:#FF7900"></i>Orange</div><div class=op style="top:1120px"><i style="background:#E60000"></i>Vodafone</div><div class=op style="top:1300px"><i style="background:#0B5FFF"></i>DIGI</div>'
def S3(): return 'dark',LOGO+'<div class=badge><span>PASUL 2</span></div><div class=t>Completezi<b>formularul</b></div><div class=field style="top:960px"><small>Numărul de telefon</small><b>07XX XXX XXX</b></div><div class=field style="top:1170px"><small>Alegi valoarea</small><b>Valoarea reîncărcării</b></div>'
def S4(): return 'light',LOGO+'<div class=badge><span>PASUL 3</span></div><div class=t>Plătești<b>prin PayU</b></div><div class=pill style="top:1000px">PayU</div><div class=foot style="top:1280px;color:#33475b">Plata și validarea<br>sunt două etape separate</div>'
def S5(): return 'dark',LOGO+'<div class=badge><span>PASUL 4</span></div><div class=t>Primești<b>creditul</b></div><div class=check style="top:960px">✓</div><div class=chips style="top:1240px;font-size:46px"><span style="color:#0b3a7a">Fără cont obligatoriu</span><span style="color:#0b3a7a">24/7</span></div><div class=btn style="top:1380px">online-prepay.ro</div><div class=foot style="top:1530px;font-size:42px">Linkul e în bio</div>'
def COV(txt,bg,fg): return 'dark','<div class=cov style="background:%s;color:%s;font-size:108px;box-shadow:0 20px 50px rgba(0,0,0,.35)">%s</div>'%(bg,fg,txt)
os.chdir('/tmp/v2')
slides=[S1,S2,S3,S4,S5]
covers=[('Cum','#37C0ED','#06323a'),('Orange','#FF7900','#fff'),('Vodafone','#E60000','#fff'),('DIGI','#0B5FFF','#fff'),('FAQ','#ffffff','#0b3a7a')]
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1080,'height':1920})
    for i,f in enumerate(slides):
        cls,body=f()
        open('t5.html','w',encoding='utf-8').write('<style>'+CSS+'</style><div id=s class="'+cls+'">'+body+'</div>')
        pg.goto('file:///tmp/v2/t5.html'); pg.wait_for_timeout(250)
        pg.locator('#s').screenshot(path='story-cum-%d.png'%(i+1))
    for i,(t,bg,fg) in enumerate(covers):
        cls,body=COV(t,bg,fg)
        open('t5.html','w',encoding='utf-8').write('<style>'+CSS+'</style><div id=s class="dark">'+body+'</div>')
        pg.goto('file:///tmp/v2/t5.html'); pg.wait_for_timeout(250)
        pg.locator('#s').screenshot(path='cover-%d-%s.png'%(i+1,t.lower()))
    br.close()
