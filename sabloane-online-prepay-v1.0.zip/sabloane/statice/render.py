# Utilizare: python render.py "TITLU" "TITLU_ACCENT" "FRAZA" "BIFA_1" "BIFA_2" "BIFA_3" "BUTON" iesire.png [culoare_accent_hex]
import sys, os, html
from playwright.sync_api import sync_playwright
d = os.path.dirname(os.path.abspath(__file__))
a = sys.argv[1:]
t = open(os.path.join(d, "template.html"), encoding="utf-8").read()
for k, v in zip(["TITLU","TITLU_ACCENT","FRAZA","BIFA_1","BIFA_2","BIFA_3","BUTON"], a[:7]):
    t = t.replace("{{%s}}" % k, html.escape(v))
t = t.replace("{{URL}}", "online-prepay.ro")
if len(a) > 8:
    t = t.replace(".t2{color:var(--ac,#1aa6dc)}", ".t2{color:%s}" % a[8])
tmp = os.path.join(d, "_tmp.html")
open(tmp, "w", encoding="utf-8").write(t)
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width":1080,"height":1350})
    pg.goto("file://" + tmp); pg.wait_for_timeout(400)
    pg.locator("#a").screenshot(path=a[7]); b.close()
os.remove(tmp)
